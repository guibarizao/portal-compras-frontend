import styled from "styled-components";

export const Container = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
  margin-top: 24px;
`;
