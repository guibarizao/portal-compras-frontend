import styled from "styled-components";

export const CheckboxArea = styled.div`
  display: flex;
  justify-content: flex-start;
  margin-left: 8px;
  margin-bottom: 32px;
`;
