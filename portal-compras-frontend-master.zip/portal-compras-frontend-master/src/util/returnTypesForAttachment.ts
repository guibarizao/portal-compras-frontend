export default function returnTypesForAttachments() {
  return ".pdf, .doc, .docx, .png, .jpg, .jpeg, .jfif, xls, .xml, .xlsx, .csv, .xlsb, .eml, .oft, .msg, .zip, .7z, .rar";
}
