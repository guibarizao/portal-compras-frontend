export default interface IFindSession {
  username: string;
  expires_in: number;
  access_token: string;
  refresh_token: string;
}
