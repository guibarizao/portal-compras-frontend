export default interface ISupplierErpStatus {
  id: number;
  description: string;
}
