export default interface ICustomFieldType {
  id?: number;
  description: string;
}
