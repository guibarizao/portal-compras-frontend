export default interface IPage {
  title: string;
}
