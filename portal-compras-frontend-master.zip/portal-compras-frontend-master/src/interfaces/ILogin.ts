export default interface ILogin {
  username: string;
  password: string;
}
