export default interface IPurchaseRequestErpStatus {
  id: number;
  description: string;
}
