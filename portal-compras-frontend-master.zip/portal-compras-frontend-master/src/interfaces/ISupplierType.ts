export default interface ISupplierType {
  id: string;
  description: string;
}
