export default interface IProjectSituation {
  id: string;
  name: string;
}
