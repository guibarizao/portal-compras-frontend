export default interface IFormError {
  [key: string]: string;
}
