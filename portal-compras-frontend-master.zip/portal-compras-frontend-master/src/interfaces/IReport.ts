export default interface IReport {
  id?: string;
  code: string;
  description: string;
  isActive: boolean;
}
