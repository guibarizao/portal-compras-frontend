export default interface IStockRequestType {
  id?: string;
  description: string;
  stockRequestProjectRequired?: boolean;
  stockRequestWalletRequired?: boolean;
}
