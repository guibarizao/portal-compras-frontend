export default interface IGeneratePurchaseRequestReportRequest {
  purchaseRequestId: string;
}
