export default interface IGenerateStockRequestReportRequest {
  stockRequestId: string;
}
