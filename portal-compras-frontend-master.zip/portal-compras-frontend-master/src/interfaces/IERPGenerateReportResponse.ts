export default interface IERPGenerateReportResponse {
  urlLogin: string;
  urlGenerate: string;
}
