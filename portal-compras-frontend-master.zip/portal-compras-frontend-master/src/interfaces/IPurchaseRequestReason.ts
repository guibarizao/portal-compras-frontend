export default interface IPurchaseRequestReason {
  id?: string;
  description: string;
}
