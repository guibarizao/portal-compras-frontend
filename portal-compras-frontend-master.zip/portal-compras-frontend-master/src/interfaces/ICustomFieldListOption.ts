export default interface ICustomFieldListOption {
  id: string;
  customFieldId: string;
  sequence: number;
  description: string;
  selectedDefault: boolean;
}
