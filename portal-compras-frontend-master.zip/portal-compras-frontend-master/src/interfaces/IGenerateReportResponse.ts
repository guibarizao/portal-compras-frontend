export default interface IGenerateReportResponse {
  file: string;
}
