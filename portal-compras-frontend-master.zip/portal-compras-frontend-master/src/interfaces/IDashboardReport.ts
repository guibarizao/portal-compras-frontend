export default interface IDashboardReport {
  purchaseRequest: number;
  stockRequest: number;
  purchaseRequestPending: number;
  stockRequestPending: number;
}
