export default interface ICustomFieldListType {
  value: string;
  description: string;
}
