export default interface IProductRequestErpStatus {
  id: number;
  description: string;
}
