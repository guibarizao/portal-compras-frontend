export default interface IPaymentCondition {
  id?: string;
  code: string;
  name: string;
  isActive?: boolean;
}
