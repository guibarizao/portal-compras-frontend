export default interface ICustomFieldDocumentType {
  id?: number;
  description: string;
}
