export default interface IStockRequestErpStatus {
  id: number;
  description: string;
}
