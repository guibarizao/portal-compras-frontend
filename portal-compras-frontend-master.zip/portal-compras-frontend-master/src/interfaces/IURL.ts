export default interface IURL {
  url: string;
}
